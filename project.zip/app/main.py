from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from . import models, schemas, database
from starlette.status import HTTP_422_UNPROCESSABLE_ENTITY
from .response import create_not_found_response, create_success_response, create_error_response, create_unauthorized_response

models.Base.metadata.create_all(bind=database.engine)  

app = FastAPI()
sch=schemas.BaseResponse


def get_db():
    db = database.SessionLocal()
    try:
        yield db
    finally:
        db.close()



@app.get("/fetch", response_model=sch)
def root_get_users(db: Session = Depends(get_db)):
    
    users = db.query(models.User).all()
    user_list = [{"id": u.id, "name": u.name, "email": u.email} for u in users]
    return create_success_response("User list fetched", {"users": user_list})
                                    #Code by defult , #Message ,#Data for user

    
@app.post("/register", response_model=sch)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(models.User.name == user.name).first()
    if existing:
        return create_error_response("Username already exists")

    new_user = models.User(name=user.name, password=user.password, email=user.email)
    db.add(new_user)
    db.commit()

    return create_success_response("Registered successfully", {"name": user.name})


@app.post("/login", response_model=sch)
def login(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.name == user.name).first()
    

    if not db_user or db_user.password != user.password:
        return create_unauthorized_response("Invalid credentials")

    return create_success_response("Login successful", {"name": user.name})

@app.post("/userId", response_model=sch)
def get_user_by_id(user_id: schemas.UserIdRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id.id).first()

    if not user:
        return create_not_found_response("User not found")

    return create_success_response("User fetched successfully", {
        "id": user.id,
        "name": user.name,
        "email": user.email
    })
@app.put("/update/{id}", response_model=sch)  
def update_user(
    id: int,
    user_update: schemas.UserUpdateRequest,
    db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.id == id).first()

    if not user:
        return create_not_found_response("User not found")

    if user_update.name is not None:
        user.name = user_update.name
    if user_update.email is not None:
        user.email = user_update.email

    db.commit()
    db.refresh(user)

    return create_success_response("User updated successfully", {
        "id": user.id,
        "name": user.name,
        "email": user.email
    })
@app.post("/deleteById", response_model=sch)
def delete_user_by_id(user_id: schemas.UserIdRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id.id).first()

    if not user:
        return create_not_found_response("User not found")

    user_info = {
        "name": user.name,
        "email": user.email
    }

    db.delete(user)
    db.commit()

    return create_success_response("User deleted successfully", user_info)
