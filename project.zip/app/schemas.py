from typing import Optional
from pydantic import BaseModel, EmailStr

class BaseResponse(BaseModel):
    code: int
    message: str
    data: dict | None = None
class UserCreate(BaseModel):
    name: str
    password: str
    email: EmailStr

class UserIdRequest(BaseModel):
    id: int

class UserUpdateRequest(BaseModel):
    name: Optional[str]
    email: Optional[EmailStr]